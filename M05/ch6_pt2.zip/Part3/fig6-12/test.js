var colors = require("colors");
console.log("colors = ", colors);